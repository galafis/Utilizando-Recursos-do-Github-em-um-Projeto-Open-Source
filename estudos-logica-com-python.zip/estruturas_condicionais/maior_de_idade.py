idade = int(input("Digite a idade: "))
if idade >= 18:
    print("Maior de idade")
else:
    print("Menor de idade")
