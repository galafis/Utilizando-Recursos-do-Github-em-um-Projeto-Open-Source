nomes = ["Ana", "Bruno", "Carlos"]
for nome in nomes:
    print(f"Olá, {nome}!")
