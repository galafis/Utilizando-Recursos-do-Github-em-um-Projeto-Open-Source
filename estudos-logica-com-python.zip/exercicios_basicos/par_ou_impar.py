def par_ou_impar(num):
    return "Par" if num % 2 == 0 else "Ímpar"

print(par_ou_impar(7))
