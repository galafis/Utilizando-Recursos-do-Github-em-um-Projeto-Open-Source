def soma(a, b):
    return a + b

print("Soma de 2 + 3 =", soma(2, 3))
