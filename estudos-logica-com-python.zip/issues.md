# [ISSUE] Função de validação de CPF

## Descrição
Seria interessante incluir uma função que valide CPFs com base na regra matemática oficial.

## Sugestão
Adicionar no diretório `desafios_avancados` com testes automatizados em seguida.
