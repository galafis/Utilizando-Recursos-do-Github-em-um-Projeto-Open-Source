# Pull Request - Adiciona verificação de número primo

## O que foi alterado
- Novo script `numero_primo.py` em `desafios_avancados/`

## Justificativa
Ampliar o repertório lógico com novos desafios de decisão condicional.
